# হিসাব লেখা — Deploy Guide

## 🚀 একবার setup (তোমাকে করতে হবে)

### 1. Firebase CLI install

```bash
npm install -g firebase-tools
firebase login
```

### 2. তোমার Admin Gmail সেট কর

`member.html` file এ এই line খোলো:

```js
const ADMIN_EMAILS = [
  "your-admin@gmail.com"   // ← তোমার Gmail এ বদলাও
];
```

**একটাই Gmail** দাও (যেটা দিয়ে Google login করবে admin panel এ)।

### 3. Firebase Console এ Phone Auth enable কর

1. https://console.firebase.google.com/project/dokan-hisab-35ca7/authentication/providers
2. **Sign-in method** tab → **Phone** → Enable → Save

### 4. Firestore Database তৈরি কর

1. https://console.firebase.google.com/project/dokan-hisab-35ca7/firestore
2. **Create database** → Production mode → asia-south1 (Mumbai) region select

### 5. Deploy

```bash
cd tally-khata
firebase deploy
```

এটা deploy করবে:
- ✅ Web app: `https://dokan-hisab-35ca7.web.app/`
- ✅ Admin panel: `https://dokan-hisab-35ca7.web.app/member`
- ✅ Firestore rules

---

## 📱 User flow (deploy এর পরে)

1. User `https://dokan-hisab-35ca7.web.app/` খোলে → Phone OTP login
2. "💎 প্রিমিয়াম নিন" → bKash `01858293479` → ৳৫০ পাঠায়
3. TrxID submit → তোমাকে WhatsApp এ link আসে:
   ```
   https://dokan-hisab-35ca7.web.app/member?phone=...&days=30&trx=...
   ```
4. তুমি link এ click → Google login (admin only) → "✅ Approve করুন"
5. **User এর app instant activate!** 🎉 (real-time listener — reopen লাগবে না, foreground এ থাকলেই 1-2 সেকেন্ডে হয়ে যাবে)

---

## 🔐 যেটা সিকিউর

- **Firestore rules**: user শুধু নিজের data দেখতে/লিখতে পারবে
- **Admin panel**: শুধু ADMIN_EMAILS এ থাকা Gmail দিয়ে login করা যাবে
- **Phone OTP**: Firebase এর মাধ্যমে (~$0.06 per verification)
- **reCAPTCHA**: invisible, spam protection

---

## 💸 Free tier limits

- **Firestore reads**: 50K/day free
- **Firestore writes**: 20K/day free
- **Phone OTP**: 10K/month free, পরে $0.06/verification
- **Hosting**: 10GB/month bandwidth free

---

## 🐛 সমস্যা হলে

**OTP আসছে না?**
- Firebase Console → Authentication → Sign-in method → Phone এ test number add করো (development এর জন্য)
- authorized domains এ তোমার domain add করো

**Admin panel এ access denied?**
- `member.html` এ ADMIN_EMAILS এ তোমার Gmail add করো
- Google account দিয়ে login করো

**Approve করার পর user app activate হচ্ছে না?**
- User app foreground এ আছে কিনা দেখো
- Console log এ `[SUB] subscription activated via server` দেখাচ্ছে কিনা দেখো
- Firestore → users/{uid}/subscription এ updatedAt timestamp update হচ্ছে কিনা দেখো
